package org.jzy3d.analysis;

public interface IRunnableAnalysis extends IAnalysis{
	public void start();
	public void stop();
}
