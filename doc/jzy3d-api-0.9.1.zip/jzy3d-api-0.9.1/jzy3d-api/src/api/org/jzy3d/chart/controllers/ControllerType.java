package org.jzy3d.chart.controllers;

public enum ControllerType {
	ZOOM,
	SHIFT,
	ROTATE,
	PAN
}
