package org.jzy3d.events;

public interface ControllerEventListener {
	public void controllerEventFired(ControllerEvent e);
}
