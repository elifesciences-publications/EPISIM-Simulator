package org.jzy3d.events;


public interface IDrawableListener {
	public void drawableChanged(DrawableChangedEvent e);
}
