package org.jzy3d.events;

public interface IScaleChangedListener {
	public void scaleChanged(ScaleChangedEvent e);
}
