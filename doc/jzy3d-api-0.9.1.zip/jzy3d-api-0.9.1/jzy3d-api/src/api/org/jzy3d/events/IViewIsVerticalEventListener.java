package org.jzy3d.events;

public interface IViewIsVerticalEventListener {
	public void viewVerticalReached(ViewIsVerticalEvent e);
	public void viewVerticalLeft(ViewIsVerticalEvent e);
}
