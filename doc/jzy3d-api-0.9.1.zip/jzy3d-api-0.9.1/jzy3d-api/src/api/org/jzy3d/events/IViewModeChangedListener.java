package org.jzy3d.events;

public interface IViewModeChangedListener {
	public void viewModeChanged(ViewModeChangedEvent e);
}
