package org.jzy3d.events;

public interface IViewPointChangedListener {
	public void viewPointChanged(ViewPointChangedEvent e);
}
