package org.jzy3d.events;

import java.util.EventObject;

public class ViewIsVerticalEvent extends EventObject {
	
	public ViewIsVerticalEvent(Object source){
		super(source);
	}
	
	/*************************************************************************/

	private static final long serialVersionUID = 7467846578948284603L;
}
