package org.jzy3d.maths;

public enum PlaneAxis {
	X, Y, Z
}
