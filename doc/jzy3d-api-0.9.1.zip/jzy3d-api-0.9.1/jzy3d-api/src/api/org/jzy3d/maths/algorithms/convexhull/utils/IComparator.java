package org.jzy3d.maths.algorithms.convexhull.utils;

public interface IComparator<T> {
	public int compare(T a, T b);
}