package org.jzy3d.plot3d.primitives.axes.layout.renderers;

public interface ITickRenderer {
	public String format(double value);
}
