package org.jzy3d.plot3d.primitives.interactive.tools;

public interface IProjection {
	public float deapness();
}
