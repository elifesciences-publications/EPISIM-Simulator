package org.jzy3d.plot3d.primitives.textured;

public interface ITranslucent {
	public void setAlphaFactor(float a);
}
