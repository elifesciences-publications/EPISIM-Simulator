package org.jzy3d.plot3d.rendering.canvas;

import java.io.File;
import java.io.IOException;

import javax.media.opengl.GLDrawable;

import org.jzy3d.plot3d.rendering.view.Renderer3d;
import org.jzy3d.plot3d.rendering.view.View;

import com.jogamp.opengl.util.texture.TextureData;


/**
 * A {@link ICanvas} represent the target component for rendering OpenGL.
 * 
 * It might be displayed on the screen in a GUI ({@link IScreenCanvas}), 
 * or simply be an offscreen component able to export an image {@link OffscreenCanvas}.
 * 
 * @see {@link IScreenCanvas}
 * 
 * @author Martin Pernollet
 */
public interface ICanvas {
	/** Returns a reference to the held view.*/
	public View getView();
        
    /** Returns the GLDrawable associated with the canvas */
    public GLDrawable getDrawable();

	/** Returns the renderer's width, i.e. the display width.*/
	public int getRendererWidth();
	
	/** Returns the renderer's height, i.e. the display height.*/
	public int getRendererHeight();	
	
	public Renderer3d getRenderer();
	
	/** Invoked when a user requires the Canvas to be repainted (e.g. a non 3d layer has changed).
	 */
	public void forceRepaint();
	
	/** Returns an image with the current renderer's size */
	public TextureData screenshot();
    public TextureData screenshot(File file) throws IOException;
	
	/** Performs all required cleanup when destroying a Canvas.*/
	public void dispose();
	
	/** A generic interface for mouse listener to remain Windowing toolkit independant. *
	 Implementation of this method should simply cast the input assuming it will correspond
	 to canvas-compatible mouse listener. */
	public void addMouseController(Object o);
	/** A generic interface for mouse listener to remain Windowing toolkit independant. *
    Implementation of this method should simply cast the input assuming it will correspond
    to canvas-compatible mouse listener. */
    public void addKeyController(Object o);	
    /** A generic interface for key listener to remain Windowing toolkit independant. *
    Implementation of this method should simply cast the input assuming it will correspond
    to canvas-compatible key listener. */
    public void removeMouseController(Object o);
    /** A generic interface for key listener to remain Windowing toolkit independant. *
    Implementation of this method should simply cast the input assuming it will correspond
    to canvas-compatible key listener. */
    public void removeKeyController(Object o);
	/* */
	
	public String getDebugInfo();

}
