package org.jzy3d.plot3d.rendering.view;

public enum ViewportMode {
    STRETCH_TO_FILL, SQUARE, RECTANGLE_NO_STRETCH
}