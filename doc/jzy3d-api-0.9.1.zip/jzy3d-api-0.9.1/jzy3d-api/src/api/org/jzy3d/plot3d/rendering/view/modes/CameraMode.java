package org.jzy3d.plot3d.rendering.view.modes;

public enum CameraMode {
	ORTHOGONAL, 
	PERSPECTIVE
}
