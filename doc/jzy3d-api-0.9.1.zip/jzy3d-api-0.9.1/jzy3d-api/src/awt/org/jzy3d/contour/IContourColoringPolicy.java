package org.jzy3d.contour;

public interface IContourColoringPolicy {
	public int getRGB(double z);
}
