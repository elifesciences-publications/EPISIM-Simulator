package org.jzy3d.plot3d.pipelines;

public class NotImplementedException extends RuntimeException {
	private static final long serialVersionUID = -7478683271586390384L;

	public NotImplementedException(){
	}
}
