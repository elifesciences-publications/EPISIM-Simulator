package org.jzy3d.plot3d.rendering.tooltips;

public interface IAction {
	public void perform();
}
