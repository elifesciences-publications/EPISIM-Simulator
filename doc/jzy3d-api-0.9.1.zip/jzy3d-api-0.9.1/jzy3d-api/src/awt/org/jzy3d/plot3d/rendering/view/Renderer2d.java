package org.jzy3d.plot3d.rendering.view;

import java.awt.Graphics;

public interface Renderer2d {
	public void paint(Graphics g);
}
