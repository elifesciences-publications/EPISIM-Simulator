package org.jzy3d.plot3d.text.renderers.jogl;

import com.jogamp.opengl.util.awt.TextRenderer;

public interface ITextStyle extends TextRenderer.RenderDelegate{

}
