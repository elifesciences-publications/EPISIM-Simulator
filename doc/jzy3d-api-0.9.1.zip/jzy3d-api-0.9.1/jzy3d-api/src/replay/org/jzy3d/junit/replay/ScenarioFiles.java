package org.jzy3d.junit.replay;

public class ScenarioFiles {
	public static String SCENARIO_FOLDER = "data/scenarios/";
	public static String FILE_EVENTS = "-events.txt";
	public static String FILE_SCREENSHOT = "-screenshot-";
}
