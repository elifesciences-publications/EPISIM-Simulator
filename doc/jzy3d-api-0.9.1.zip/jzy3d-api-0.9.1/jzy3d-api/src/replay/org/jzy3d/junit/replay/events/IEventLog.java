package org.jzy3d.junit.replay.events;

public interface IEventLog {
	public long since();
}
