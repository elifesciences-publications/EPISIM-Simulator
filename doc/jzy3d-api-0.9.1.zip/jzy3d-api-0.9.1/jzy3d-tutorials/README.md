jzy3d-tutorials
===================

Provide examples on how to create:
- surface charts
- scatter charts

